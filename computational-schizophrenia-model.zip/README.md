# Computational Modeling of Schizophrenia

This project explores a simplified computational model inspired by the **dopamine reward prediction error hypothesis** of schizophrenia.

## Background

In computational psychiatry, **reinforcement learning models** have been used to simulate how abnormalities in reward-based learning may contribute to symptoms of schizophrenia such as delusions and hallucinations.

This project implements a toy RL model that simulates an agent's behavior under normal vs. psychotic-like reward processing.

## Features

- Temporal Difference (TD) learning agent
- Adjustable dopamine sensitivity
- Visualization of reward prediction error
- Simple synthetic symptom data generator

## Dependencies

- Python 3.9+
- numpy
- matplotlib
- pandas (optional)

## Getting Started

```bash
git clone https://github.com/coolecho2018/computational-schizophrenia-model.git
cd computational-schizophrenia-model
python schizophrenia_model.py
```

## Example Output

![Example Plot](plots/reward_prediction_error.png)

## Author

Echo Yin – Patient-researcher passionate about computational approaches to psychiatry.
