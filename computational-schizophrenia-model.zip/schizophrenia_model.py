import numpy as np
import matplotlib.pyplot as plt
import os

# Parameters
alpha = 0.1  # learning rate
gamma = 0.9  # discount factor
dopamine_noise = 0.5  # simulate "dopamine dysregulation"

# Rewards for two states
true_rewards = [1, -1]

# Initialize Q-values
Q = [0, 0]
errors = []

# Learning loop
for episode in range(50):
    state = np.random.choice([0, 1])  # randomly pick state
    reward = true_rewards[state]

    # Add noise to reward to simulate dopamine error
    noisy_reward = reward + np.random.normal(0, dopamine_noise)

    # TD update
    error = noisy_reward - Q[state]
    Q[state] += alpha * error
    errors.append(error)

# Plot prediction error over time
os.makedirs("plots", exist_ok=True)
plt.plot(errors)
plt.title("Reward Prediction Errors Over Time")
plt.xlabel("Episode")
plt.ylabel("Prediction Error")
plt.savefig("plots/reward_prediction_error.png")
plt.show()
